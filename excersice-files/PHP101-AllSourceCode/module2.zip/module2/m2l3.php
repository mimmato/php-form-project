<?php
$folder_name = 'testing';
$folder_path = 'testingtwo/nextfolder/lastfolder';

//mkdir( $folder_name, 0755 );
mkdir( $folder_path, 0755, true );
