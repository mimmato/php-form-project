<?php
define('DB_NAME', 'snippets');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_HOST', 'localhost');
